class_name Player
extends CharacterBody2D
## 主角。输入从 Controls 的一个前缀读（solo / kb_left / pad0 ……），
## 所以同一份代码给 1~4 个玩家用。数值见 策划案.txt 第六节。
## 原点在脚底中间。

# —— 移动 ——
# 2026-10-17 第二次试玩：嫌慢、嫌笨重，照空洞骑士调——起停几乎是瞬间的。
# 第三次试玩：之前说"慢"指的是提灯的速度，空手 115 正合适，提灯按原比例（约 0.78）是 90。
# 角色 20 像素高，115 像素/秒 ≈ 每秒 6 个身高，横穿一屏约 4 秒。
const RUN_SPEED := 115.0
const CARRY_SPEED := 90.0
const ACCEL_TIME := 0.07
const DECEL_TIME := 0.05
const AIR_CONTROL := 1.0
const CHARGE_MOVE_MULT := 0.7
# —— 跳跃（空洞骑士式）——
# 按住跳跃键时匀速上升（最多 JUMP_HOLD_TIME 秒），松手或到时间才开始受重力，
# 所以弧线是平顶的"半圆"，不是又高又窄的尖抛物线。
# 满按：约 45 像素高、空中约 0.54 秒。实测（tools: -- --arc）：空手跑着跳约 62 像素远，提灯约 49。
# 点一下：最少也匀速升 JUMP_MIN_HOLD 秒，约 23 像素高。
const JUMP_VELOCITY := -190.0
const JUMP_HOLD_TIME := 0.16
const JUMP_MIN_HOLD := 0.05
const GRAVITY := 1300.0
const FALL_GRAVITY_MULT := 1.35
# 10-18 美术哥 Oscar 试玩：「向下是慢慢加速的，现在跳起来躲弹幕很困难」——上升段不动（跳多高不变），只改下落：
# 顶点悬停更久；下落重力先小后大（FALL_RAMP_TIME 秒内从 FALL_GRAVITY_START 涨到 FALL_GRAVITY_MULT）；最大下落速度 400 → 300。
# 空中按住"下"（不按攻击时）快速下落，想快点落地照样能快。
const MAX_FALL_SPEED := 300.0
const FALL_GRAVITY_START := 0.55
const FALL_RAMP_TIME := 0.35
## 空中按住"下"：重力倍率、最大下落速度。按着攻击时不算（霰弹枪朝脚下喷、激光往下压用的也是"下"）
const FAST_FALL_MULT := 2.2
const FAST_FALL_SPEED := 460.0
const APEX_SPEED := 30.0
## 顶点悬停：速度很小的那一段重力打折（按住跳 ×0.35，不按 ×0.6），最长 APEX_TIME 秒
const APEX_GRAVITY_MULT := 0.35
const APEX_GRAVITY_MULT_RELEASED := 0.6
const APEX_TIME := 0.12
const COYOTE_TIME := 0.10
## 站在单向平台上按"下"（S）就从平台上穿下去；这么久之内不和那块平台碰撞
const DROP_TIME := 0.25
const JUMP_BUFFER_TIME := 0.10
## 撞头修正（夜间打磨）：往上跳时头只蹭到平台角这么几像素，就把人往旁边挪一下让他过去，不被顶下来
const CORNER_NUDGE := 4
## 上台面补救：下落时贴着台边往前推，台面只比脚高这么几像素，就把人抬上去（差一点就跳上去的那种）
const LEDGE_ASSIST := 4
# —— 火箭靴 ——
const JET_MAX_UP := 120.0
const JET_ACCEL := 1500.0
## 下落中开喷：先用更大的推力止跌，不然从快速下落里要 0.35 秒才停得住，手感发飘
const JET_BRAKE_MULT := 1.8
## 一直按着跳跃键时，上升速度慢到这个值（快到顶点）就自动接上喷气
const JET_ARM_SPEED := -40.0
const FUEL_TIME := 1.0
const FUEL_TIME_CARRY := 0.7
const FUEL_UPGRADE := 0.35
const FUEL_REFILL_DELAY := 0.25
const FUEL_REFILL_TIME := 1.2
const JET_VOLUME_DB := -17.0
const JET_SILENT_DB := -50.0
# —— 攻击 ——
const CHARGE_TIME := 0.5
const CHARGE_UPGRADE := 0.08
const CHARGE_TIME_MIN := 0.3
const SHOT_COOLDOWN := 0.12
## 三把武器（开局选，见 weapon_select.gd；商店也能换）。单体每秒伤害都在 100 左右：
##   flash  闪光灯：按住蓄力 0.5 秒（10-18 打击感：0.6 → 0.5，节奏不断），蓄满 100 伤害、更快更大、穿透一排；没蓄满也有 35~80 伤害、只微微下坠
##   rivet  铆钉枪：按住一直连发，每 0.1 秒一颗、每颗 13 伤害，散布 ±9°（散开能顺带打到旁边的怪），射程短、尽头逐渐消失，有后坐
##   hammer 蒸汽锤：按一下，0.12 秒后以自己为中心炸一圈（半径 48，圈里统一 140 伤害，吹散 Boss 子弹），冷却 1.15 秒
##          （10-18 打击感：原来 170 伤害、冷却 1.6 秒，两锤之间干等太久；冷却快好时按下会先记着，一好就砸）
## （2026-10-17 作者试玩后改：闪光灯太弱、蓄力表现太夸张、铆钉枪要更散更痛、蒸汽锤要近高远低）
## 快充升级对三把都有效：蓄力更快 / 射得更快 / 冷却更短
const RIVET_INTERVAL := 0.1
const RIVET_UPGRADE := 0.01
const RIVET_SPREAD := 9.0
const RIVET_MOVE_MULT := 0.8
const RIVET_RECOIL := 10.0
const HAMMER_COOLDOWN := 1.15
const HAMMER_UPGRADE := 0.15
## 冷却还剩这么多秒以内按下，先记着，冷却一好就砸（输入缓冲）
const HAMMER_BUFFER := 0.3
const HAMMER_WINDUP := 0.12
## 蓄力圈：身边一圈 12 个点，蓄到哪亮到哪（作者：别太夸张）
const CHARGE_DOTS := 12
const CHARGE_RING_R := 10.0
## 比屏幕半宽（2 倍放大后 120）略小，不锁屏幕外的怪
const AIM_RANGE := 115.0
## Boss 块头大、常常离得远（吊在头顶、在地上乱跑），自动瞄准对 Boss 放宽到这么远（夜间打磨：站桩测试里高台上打不到 Boss）
const AIM_RANGE_BOSS := 200.0
## 身后的敌人按距离 ×1.8 算，面朝的方向优先
const BEHIND_PENALTY := 1.8
# —— 挨打 ——
## 2026-10-17 作者试玩嫌短：1.0 → 1.4 秒，期间明显闪烁（藏 / 高亮 / 正常 三拍轮着来）
const INVULN_TIME := 1.4
## 无敌闪烁一拍多长
const BLINK_STEP := 0.06
const STUN_TIME := 0.4
const EMOTION_HIT_CARRY := 3.0  # 按策划案第八节（原 +5/+8 太快过载）
const EMOTION_HIT_EMPTY := 6.0

const STRIP_COLORS := {
	"red": Color8(255, 192, 192),
	"robot": Color8(255, 225, 194),
	"bird": Color8(201, 212, 255),
	"dino": Color8(218, 255, 206),
}
const FRAME_SIZE := Vector2i(16, 20)
## 蓄力开始时整个人往下一缩再弹回来（以脚底为支点）
const SQUASH_TIME := 0.16
const SQUASH_SCALE := Vector2(1.25, 0.72)
const IDLE_FRAME_TIME := 0.2
const WALK_FRAME_TIME := 0.13

@export var input_prefix := "solo"
@export var skin := "red"

var facing := 1
var crystal: Crystal = null
## 剩余油量，0~1
var fuel := 1.0
var charge := 0.0
var charging := false
var charge_full := false
var strip_color := Color.WHITE
## 升级等级（0~3），升级房间做好以后由 Run 写进来
var charge_level := 0
var fuel_level := 0

var _coyote := 0.0
var _drop_t := 0.0
var _drop_bodies: Array[PhysicsBody2D] = []
var _buffer := 0.0
var _jump_hold := 0.0
var _jump_min := 0.0
var _apex := 0.0
## 这次下落已经落了多久（下落重力先小后大用）
var _fall_t := 0.0
var _jetting := false
var _jet_armed := false
var _ground_time := 0.0
var _cooldown := 0.0
var _invuln := 0.0
var _stun := 0.0
var _anim_time := 0.0
var _walk_time := 0.0
var _ring := 0.0
var _squash := 0.0
var _gather := 0.0
var _release_flash := 0.0
var _target: Node2D = null
var _rivet_t := 0.0
var _rivet_n := 0
var _muzzle := 0.0
var _hammer_cd := 0.0
var _hammer_windup := 0.0
var _hammer_buffer := 0.0
## 新武器（WeaponRegistry 里有 handler 的）的出招脚本：每个主角一份，换武器时重建（见 _weapon_handler）
var _handler: WeaponHandler = null
var _handler_id := ""
## 闪光灯出手的枪口火光（比铆钉枪的大、亮 3~4 帧），蓄满的另画一种
var _flash_muzzle := 0.0
var _flash_muzzle_full := false
## 画面上把精灵对齐到整像素：物理位置保留小数，只有显示取整（照 Phage）
var _snap := Vector2.ZERO
var _push := Vector2.ZERO

var _body: Sprite2D
var _strip: Sprite2D
var _light: PointLight2D
var _smoke: CPUParticles2D
var _jet_light: PointLight2D
var _last_walk_frame := -1
var _jet_sound: AudioStreamPlayer
var _charge_sound: AudioStreamPlayer
var _reticle: Node2D


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1
	floor_snap_length = 3.0
	Upgrades.apply(self)        # 商店买的快充、大油箱
	strip_color = STRIP_COLORS.get(skin, Color.WHITE)

	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(6, 16)
	shape.shape = rect
	shape.position = Vector2(0, -8)
	add_child(shape)

	_body = _make_sprite("res://art/chars/%s_body.png" % skin)
	_strip = _make_sprite("res://art/chars/%s_strip.png" % skin)
	# 荧光条不吃场景压暗，永远是亮的
	var unshaded := CanvasItemMaterial.new()
	unshaded.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	_strip.material = unshaded

	_light = PointLight2D.new()
	_light.texture = Game.light_texture()
	_light.color = strip_color
	_light.range_item_cull_mask = 1 | 2
	_light.position = Vector2(0, -10)
	add_child(_light)

	# 喷气的雾：用角色自己荧光条的颜色，不吃场景压暗，黑处也看得见
	_smoke = CPUParticles2D.new()
	_smoke.emitting = false
	_smoke.amount = 70
	_smoke.lifetime = 0.8
	_smoke.local_coords = false
	_smoke.direction = Vector2.DOWN
	_smoke.spread = 40.0
	_smoke.initial_velocity_min = 35.0
	_smoke.initial_velocity_max = 75.0
	_smoke.damping_min = 110.0
	_smoke.damping_max = 170.0
	_smoke.gravity = Vector2(0, -18)
	# 方块大小一律整格（美术巡检）：基础 3 格，随时间一档一档跳 2 → 3 → 4 格，不做平滑缩放
	_smoke.scale_amount_min = 3.0
	_smoke.scale_amount_max = 3.0
	var smoke_scale := Curve.new()
	smoke_scale.max_value = 2.0
	smoke_scale.add_point(Vector2(0.0, 2.0 / 3.0), 0.0, 0.0, Curve.TANGENT_LINEAR, Curve.TANGENT_LINEAR)
	smoke_scale.add_point(Vector2(0.299, 2.0 / 3.0), 0.0, 0.0, Curve.TANGENT_LINEAR, Curve.TANGENT_LINEAR)
	smoke_scale.add_point(Vector2(0.3, 1.0), 0.0, 0.0, Curve.TANGENT_LINEAR, Curve.TANGENT_LINEAR)
	smoke_scale.add_point(Vector2(0.699, 1.0), 0.0, 0.0, Curve.TANGENT_LINEAR, Curve.TANGENT_LINEAR)
	smoke_scale.add_point(Vector2(0.7, 4.0 / 3.0), 0.0, 0.0, Curve.TANGENT_LINEAR, Curve.TANGENT_LINEAR)
	smoke_scale.add_point(Vector2(1.0, 4.0 / 3.0), 0.0, 0.0, Curve.TANGENT_LINEAR, Curve.TANGENT_LINEAR)
	_smoke.scale_amount_curve = smoke_scale
	# 荧光条本身颜色很浅，雾一变透明就发灰，所以雾用它的高饱和版本
	var mist := Color.from_hsv(strip_color.h, maxf(strip_color.s, 0.6), 1.0)
	var smoke_ramp := Gradient.new()
	smoke_ramp.set_color(0, mist.lerp(Color.WHITE, 0.6))
	smoke_ramp.add_point(0.15, Color(mist.r, mist.g, mist.b, 0.9))
	smoke_ramp.add_point(0.6, Color(mist.r * 0.8, mist.g * 0.8, mist.b * 0.8, 0.45))
	smoke_ramp.set_color(1, Color(mist.r * 0.6, mist.g * 0.6, mist.b * 0.6, 0.0))
	# 颜色按档跳（亮 → 本色 → 暗半透明 → 没），不做连续渐变
	smoke_ramp.interpolation_mode = Gradient.GRADIENT_INTERPOLATE_CONSTANT
	_smoke.color_ramp = smoke_ramp
	var smoke_mat := CanvasItemMaterial.new()
	smoke_mat.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	_smoke.material = smoke_mat
	_smoke.position = Vector2(0, -1)
	add_child(_smoke)
	# 喷气时脚下一盏同色的灯，把周围照亮
	_jet_light = PointLight2D.new()
	_jet_light.texture = Game.light_texture()
	_jet_light.color = Color.from_hsv(strip_color.h, maxf(strip_color.s, 0.6), 1.0)
	_jet_light.energy = 0.0
	_jet_light.texture_scale = 1.4
	_jet_light.range_item_cull_mask = 1 | 2
	_jet_light.position = Vector2(0, 4)
	add_child(_jet_light)

	# 喷气声：无缝循环，起停时淡入淡出
	var jet_stream := Game.load_sound("jetpack").duplicate() as AudioStreamWAV
	jet_stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	jet_stream.loop_begin = 0
	jet_stream.loop_end = jet_stream.data.size() / 2
	_jet_sound = AudioStreamPlayer.new()
	_jet_sound.stream = jet_stream
	_jet_sound.volume_db = JET_SILENT_DB
	add_child(_jet_sound)
	_charge_sound = AudioStreamPlayer.new()
	_charge_sound.stream = Game.load_sound("charge")
	_charge_sound.volume_db = -15.0
	add_child(_charge_sound)

	_reticle = Node2D.new()
	_reticle.top_level = true
	_reticle.z_index = 20
	_reticle.draw.connect(_draw_reticle)
	add_child(_reticle)


func _make_sprite(path: String) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = load(path)
	s.hframes = 7
	s.centered = false
	s.offset = Vector2(-8, -FRAME_SIZE.y)
	add_child(s)
	return s


func _act(action: String) -> String:
	return input_prefix + "_" + action


func charge_time() -> float:
	return maxf(CHARGE_TIME - CHARGE_UPGRADE * charge_level, CHARGE_TIME_MIN)


func fuel_time() -> float:
	return (FUEL_TIME_CARRY if crystal else FUEL_TIME) + FUEL_UPGRADE * fuel_level


func is_jetting() -> bool:
	return _jetting


func _physics_process(delta: float) -> void:
	var on_floor := is_on_floor()
	_coyote -= delta
	_buffer -= delta
	_cooldown -= delta
	_invuln -= delta
	_stun -= delta
	_ring = maxf(_ring - delta * 5.0, 0.0)
	_squash = maxf(_squash - delta / SQUASH_TIME, 0.0)
	_gather = maxf(_gather - delta / 0.18, 0.0)
	_release_flash = maxf(_release_flash - delta / 0.15, 0.0)

	var axis := 0.0
	if _stun <= 0.0:
		axis = Input.get_axis(_act("left"), _act("right"))
	_move_x(axis, delta, on_floor)
	if _drop_through(delta, on_floor):
		on_floor = false
	_jump_and_gravity(delta, on_floor)
	_attack(delta)
	_crystal_input()

	var fall_speed := velocity.y
	_corner_nudge(delta)
	move_and_slide()
	_ledge_assist(axis)
	# 外力（Boss 吸气之类）按位移直接挪，不进 velocity，免得被走路的加减速抵消
	if _push != Vector2.ZERO:
		move_and_collide(_push * delta)
		_push = Vector2.ZERO
	if not on_floor and is_on_floor() and fall_speed > 140.0:
		Game.sfx("land", -14.0 + clampf((fall_speed - 140.0) / 30.0, 0.0, 8.0), 1.0, 0.1)
		Game.dust(get_parent(), global_position, 3 + int(clampf((fall_speed - 140.0) / 60.0, 0.0, 4.0)))
		if fall_speed > 330.0:
			Game.add_shake(2.0)
		# 落地压扁：落得越快压得越扁（蓄力时的压扁优先）
		if _squash <= 0.0:
			_squash = clampf(0.4 + (fall_speed - 140.0) / 400.0, 0.4, 0.75)

	_animate(delta)
	queue_redraw()
	_reticle.queue_redraw()


func _move_x(axis: float, delta: float, on_floor: bool) -> void:
	if axis != 0.0:
		facing = 1 if axis > 0.0 else -1
	var top := CARRY_SPEED if crystal else RUN_SPEED
	if charging:
		if _handler != null:
			top *= _handler.move_mult()
		else:
			top *= RIVET_MOVE_MULT if weapon() == "rivet" else CHARGE_MOVE_MULT
	var accel := RUN_SPEED / ACCEL_TIME
	var decel := RUN_SPEED / DECEL_TIME
	var rate: float
	if _stun > 0.0:
		rate = decel * 0.4
	elif axis == 0.0:
		rate = decel
	elif velocity.x != 0.0 and signf(axis) != signf(velocity.x):
		rate = decel + accel
	elif absf(velocity.x) > top:
		rate = decel
	else:
		rate = accel
	if not on_floor:
		rate *= AIR_CONTROL
	# 地上急转身：脚前蹭出一小团灰
	if on_floor and axis != 0.0 and signf(axis) != signf(velocity.x) and absf(velocity.x) > RUN_SPEED * 0.6:
		Game.dust(get_parent(), global_position + Vector2(signf(velocity.x) * 3, 0), 3, signf(velocity.x))
	velocity.x = move_toward(velocity.x, axis * top, rate * delta)
	# 已经贴着墙还往墙里推：横向速度直接清零。不然每帧都"推进墙里再被弹出来"，
	# 贴墙站着、贴墙跳、贴墙往下掉时都会一顿一顿地抖
	if velocity.x != 0.0 and _against_wall(signf(velocity.x)):
		velocity.x = 0.0


## 往上跳时，头顶只差几像素就能擦过平台的角：把人横着挪过去，不让他撞头掉下来（Celeste 式的撞角修正）
func _corner_nudge(delta: float) -> void:
	if velocity.y >= 0.0:
		return
	var up := Vector2(0.0, velocity.y * delta - 1.0)
	if not test_move(global_transform, up):
		return
	var dirs := [1, -1] if velocity.x >= 0.0 else [-1, 1]
	for off in range(1, CORNER_NUDGE + 1):
		for d in dirs:
			var side := Vector2(off * d, 0.0)
			if test_move(global_transform, side):
				continue
			if not test_move(global_transform.translated(side), up):
				position.x += off * d
				return


## 下落（或刚过最高点）时贴着台边往前推：台面只比脚高 1~LEDGE_ASSIST 像素，就把人抬上台面
func _ledge_assist(axis: float) -> void:
	if axis == 0.0 or is_on_floor() or velocity.y < -20.0 or _stun > 0.0:
		return
	var dir := signf(axis)
	if not _against_wall(dir):
		return
	for up in range(1, LEDGE_ASSIST + 1):
		var lifted := global_transform.translated(Vector2(0.0, -up))
		if test_move(global_transform, Vector2(0.0, -up)):
			return
		if not test_move(lifted, Vector2(dir * 2.0, 0.0)):
			position += Vector2(dir * 2.0, -up)
			velocity.y = 0.0
			return


## 这个方向上是不是紧贴着一面竖直的墙（斜坡不算，斜坡要能走上去）
func _against_wall(dir: float) -> bool:
	var hit := move_and_collide(Vector2(dir * 0.5, 0.0), true, safe_margin, true)
	return hit != null and absf(hit.get_normal().x) > 0.9


## 站在单向平台上按"下"：暂时不和脚下那块平台碰撞，掉下去。返回 true 表示这一帧开始往下掉。
## 只对单向平台（one_way_collision）有用，实心地面按了没反应。
func _drop_through(delta: float, on_floor: bool) -> bool:
	if _drop_t > 0.0:
		_drop_t -= delta
		if _drop_t <= 0.0:
			for b in _drop_bodies:
				if is_instance_valid(b):
					remove_collision_exception_with(b)
			_drop_bodies.clear()
	if not on_floor or _stun > 0.0 or not Input.is_action_just_pressed(_act("down")):
		return false
	var found := false
	for i in get_slide_collision_count():
		var c := get_slide_collision(i)
		if c.get_normal().y > -0.7:
			continue
		var shape := c.get_collider_shape()
		var one_way: bool = (shape is CollisionShape2D and shape.one_way_collision) \
			or (shape is CollisionPolygon2D and shape.one_way_collision)
		var body := c.get_collider() as PhysicsBody2D
		if one_way and body:
			found = true
			if not _drop_bodies.has(body):
				add_collision_exception_with(body)
				_drop_bodies.append(body)
	if not found:
		return false
	_drop_t = DROP_TIME
	_coyote = 0.0
	position.y += 1.0
	velocity.y = maxf(velocity.y, 40.0)
	return true


func _jump_and_gravity(delta: float, on_floor: bool) -> void:
	var jump_held := Input.is_action_pressed(_act("jump"))
	if on_floor:
		_coyote = COYOTE_TIME
		_jet_armed = false
	if Input.is_action_just_pressed(_act("jump")):
		_buffer = JUMP_BUFFER_TIME
		if not on_floor and _coyote <= 0.0:
			_jet_armed = true

	if _buffer > 0.0 and _coyote > 0.0 and _stun <= 0.0:
		velocity.y = JUMP_VELOCITY
		_buffer = 0.0
		_coyote = 0.0
		_jump_hold = JUMP_HOLD_TIME
		_jump_min = JUMP_MIN_HOLD
		_apex = APEX_TIME
		Game.sfx("jump", -14.0, 1.0, 0.08)
		Game.dust(get_parent(), global_position, 6)
		# 起跳时身子往上拉长一下（_squash 小于 0.35 时走"拉长回弹"那段）
		if _squash <= 0.0:
			_squash = 0.3

	var want_jet := not on_floor and jump_held and fuel > 0.0 and _stun <= 0.0 \
		and _jump_hold <= 0.0 and (_jet_armed or velocity.y > JET_ARM_SPEED)
	if is_on_ceiling():
		_jump_hold = 0.0
	if _jump_hold > 0.0 and (jump_held or _jump_min > 0.0) and _stun <= 0.0:
		# 匀速上升段
		_jetting = false
		velocity.y = JUMP_VELOCITY
		_jump_hold -= delta
		_jump_min -= delta
	elif want_jet:
		_jump_hold = 0.0
		_jetting = true
		var jet_accel := JET_ACCEL * (JET_BRAKE_MULT if velocity.y > 0.0 else 1.0)
		velocity.y = move_toward(velocity.y, -JET_MAX_UP, jet_accel * delta)
		fuel = maxf(fuel - delta / fuel_time(), 0.0)
	else:
		_jump_hold = 0.0
		_jetting = false
		var g := GRAVITY
		var max_fall := MAX_FALL_SPEED
		if velocity.y > 0.0:
			_fall_t += delta
			g *= lerpf(FALL_GRAVITY_START, FALL_GRAVITY_MULT, clampf(_fall_t / FALL_RAMP_TIME, 0.0, 1.0))
		else:
			_fall_t = 0.0
		if absf(velocity.y) < APEX_SPEED and _apex > 0.0:
			g *= APEX_GRAVITY_MULT if jump_held else APEX_GRAVITY_MULT_RELEASED
			_apex -= delta
		# 空中按住"下"、没按攻击：快速下落
		if not on_floor and _stun <= 0.0 and Input.is_action_pressed(_act("down")) \
				and not Input.is_action_pressed(_act("attack")):
			g = GRAVITY * FAST_FALL_MULT
			max_fall = FAST_FALL_SPEED
		velocity.y = minf(velocity.y + g * delta, max_fall)
	_smoke.emitting = _jetting
	var flicker := 0.85 + 0.15 * sin(_anim_time * 37.0)
	_jet_light.energy = move_toward(_jet_light.energy, 1.6 * flicker if _jetting else 0.0, delta * 8.0)
	_update_jet_sound(delta)

	if on_floor:
		_ground_time += delta
		if _ground_time > FUEL_REFILL_DELAY:
			fuel = minf(fuel + delta / FUEL_REFILL_TIME, 1.0)
	else:
		_ground_time = 0.0


func _update_jet_sound(delta: float) -> void:
	if _jetting and not _jet_sound.playing:
		_jet_sound.volume_db = JET_SILENT_DB
		_jet_sound.play(randf() * 1.5)
	var target := JET_VOLUME_DB if _jetting else JET_SILENT_DB
	var speed := 400.0 if _jetting else 160.0  # 分贝每秒：起得快，收得柔
	_jet_sound.volume_db = move_toward(_jet_sound.volume_db, target, speed * delta)
	if not _jetting and _jet_sound.playing and _jet_sound.volume_db <= JET_SILENT_DB + 0.5:
		_jet_sound.stop()


## 自己手里那把（双人各拿各的，存在 Run.players 里）
func weapon() -> String:
	return Upgrades.weapon_for(input_prefix)


## 商店里换武器（shop_room.gd 调）
func set_weapon(w: String) -> void:
	_cancel_charge()
	Upgrades.set_weapon_for(input_prefix, w)
	_muzzle = 0.0


func _attack(delta: float) -> void:
	# 枪口火光只亮 1~2 帧（合金弹头式的"一帧一闪"）
	_muzzle = maxf(_muzzle - delta / 0.035, 0.0)
	_flash_muzzle = maxf(_flash_muzzle - delta / 0.06, 0.0)
	# 新武器：出招全在 handler 里（scripts/combat/weapons/）
	var h := _weapon_handler()
	if h != null:
		h.attack(delta)
		return
	match weapon():
		"rivet":
			_attack_rivet(delta)
			return
		"hammer":
			_attack_hammer(delta)
			return
	var held := Input.is_action_pressed(_act("attack"))
	if held and not charging and _cooldown <= 0.0 and _stun <= 0.0:
		charging = true
		charge = 0.0
		charge_full = false
		_charge_sound.pitch_scale = CHARGE_TIME / charge_time()
		_charge_sound.play()
		_squash = 0.35
		_gather = 0.5
	if not charging:
		_target = null
		return
	charge = minf(charge + delta / charge_time(), 1.0)
	if charge >= 1.0 and not charge_full:
		charge_full = true
		_ring = 0.5
		Game.sfx("ready", -6.0)
	_target = _find_target()
	if not held:
		_fire()


func _fire() -> void:
	var muzzle := global_position + Vector2(facing * 5, -11)
	var dir := Vector2(facing, 0)
	if _target:
		dir = (_aim_point(_target) - muzzle).normalized()
	var orb := Orb.new()
	orb.setup(self, muzzle, dir, charge, _target if charge_full else null, strip_color)
	get_parent().add_child(orb)
	Mutations.on_attack(self, orb)
	# 10-18 打击感：出手这一下要"响"——枪口一大团火光、人往后顶、震一下、两层声音叠起来
	_flash_muzzle = 1.0
	_flash_muzzle_full = charge_full
	if charge_full:
		Game.sfx("shoot", -4.0, 1.0, 0.05)
		Game.sfx("flash_boom", -5.0, 1.0, 0.06)
		velocity.x -= dir.x * 75.0
		_squash = 0.3
		Game.add_shake(1.6)
		# 灯头冒一小股热气
		Game.sparks(get_parent(), muzzle, Color(0.75, 0.75, 0.8), 4, 35.0, Vector2.UP)
	else:
		Game.sfx("shoot", -7.0, 1.25, 0.06)
		Game.sfx("flash_boom", -17.0, 1.7, 0.08)
		velocity.x -= dir.x * 25.0
		Game.add_shake(0.5)
	_release_flash = 1.0 if charge_full else 0.5
	_cancel_charge()
	_cooldown = SHOT_COOLDOWN


## 铆钉枪：按住就连发，不蓄力。每颗自动瞄最近的怪，带一点散布；人往后顶一下，枪口闪一下
func _attack_rivet(delta: float) -> void:
	_rivet_t -= delta
	var held := Input.is_action_pressed(_act("attack"))
	charging = held and _stun <= 0.0
	if not charging:
		_target = null
		_rivet_n = 0
		return
	_target = _find_target()
	if _rivet_t > 0.0:
		return
	_rivet_t += maxf(RIVET_INTERVAL - RIVET_UPGRADE * charge_level, 0.05)
	if _rivet_t < 0.0:
		_rivet_t = 0.0
	var muzzle := global_position + Vector2(facing * 6, -10)
	var dir := Vector2(facing, 0)
	if _target:
		dir = (_aim_point(_target) - muzzle).normalized()
		if signf(dir.x) != 0.0:
			facing = int(signf(dir.x))
	# 散布照合金弹头重机枪：不是乱散，而是有规律地上下来回扫开（加一点小抖动）
	# 扫的幅度取散布的 75%：正弦扫在两头停得久，用满 ±9° 打矮个子小怪会掉不少伤害
	var sweep := sin(_rivet_n * 0.9) * RIVET_SPREAD * 0.75 + randf_range(-1.5, 1.5)
	dir = dir.rotated(deg_to_rad(sweep))
	var r := Rivet.new()
	r.setup(muzzle, dir, strip_color)
	get_parent().add_child(r)
	Mutations.on_attack(self, r)
	_rivet_n += 1
	_muzzle = 1.0
	_release_flash = maxf(_release_flash, 0.35)
	velocity.x -= dir.x * RIVET_RECOIL
	# 10-18 作者"声音有点吵"：换成低沉的"哒"、音量压低、每发音高随机一点
	Game.sfx("rivet_shot", -13.0, 1.0, 0.12)
	if _rivet_n % 3 == 0:
		Game.add_shake(0.4)
	# 弹壳往身后上方抛出去，落地弹一下
	var c := Casing.new()
	c.position = global_position + Vector2(facing * 2, -10)
	c.velocity = Vector2(-facing * randf_range(30.0, 60.0), -randf_range(70.0, 110.0))
	c.ground_y = global_position.y - 1.0
	get_parent().add_child(c)


func hammer_cooldown() -> float:
	return maxf(HAMMER_COOLDOWN - HAMMER_UPGRADE * charge_level, 0.75)


## 蒸汽锤：按一下，缩一下身子蓄 0.12 秒，以自己为中心炸开一圈蒸汽；之后要冷却
func _attack_hammer(delta: float) -> void:
	var was := _hammer_cd
	_hammer_cd = maxf(_hammer_cd - delta, 0.0)
	if was > 0.0 and _hammer_cd <= 0.0:
		# 冷却好了：汽阀"噗"一声，人身上闪一下
		Game.sfx("blast_ready", -10.0)
		_ring = 0.25
	if _hammer_windup > 0.0:
		_hammer_windup -= delta
		if _hammer_windup <= 0.0:
			_blast()
		return
	_hammer_buffer = maxf(_hammer_buffer - delta, 0.0)
	if Input.is_action_just_pressed(_act("attack")) and _stun <= 0.0:
		if _hammer_cd > HAMMER_BUFFER:
			# 冷却还早：只轻轻"嘶"一声汽阀，不放"不行"的提示音（10-18：负反馈让节奏更断）
			Game.sfx("blast_ready", -20.0, 0.7)
			return
		_hammer_buffer = HAMMER_BUFFER
	if _hammer_buffer > 0.0 and _hammer_cd <= 0.0 and _stun <= 0.0:
		_hammer_buffer = 0.0
		_hammer_windup = HAMMER_WINDUP
		_squash = 0.45
		Game.sfx("scrape", -12.0, 1.8)


func _blast() -> void:
	var b := SteamBlast.new()
	b.color = strip_color
	b.position = global_position + Vector2(0, -10)
	b.grounded = is_on_floor()
	# 蒸汽锤一进场景就结算伤害，所以变异（怒火的倍率等）要在 add_child 之前算
	Mutations.on_attack(self, b)
	get_parent().add_child(b)
	_hammer_cd = hammer_cooldown()
	_release_flash = 0.6
	_ring = 0.35
	if not is_on_floor():
		velocity.y = minf(velocity.y, -90.0)


func _cancel_charge() -> void:
	if _handler != null:
		_handler.cancel()
	charging = false
	charge_full = false
	charge = 0.0
	_target = null
	_charge_sound.stop()


## 当前武器的出招脚本（老三把返回 null）。武器换了就把旧的停掉、按注册表建新的
func _weapon_handler() -> WeaponHandler:
	var w := weapon()
	if w == _handler_id:
		return _handler
	if _handler != null:
		_handler.cancel()
	_handler_id = w
	_handler = null
	var path := WeaponRegistry.handler_path(w)
	if path != "" and ResourceLoader.exists(path):
		_handler = (load(path) as GDScript).new() as WeaponHandler
		if _handler != null:
			_handler.p = self
			_handler.id = w
	return _handler


# —— 给新武器用的公开接口（WeaponHandler 里的 p 调这些；说明见 weapon_handler.gd）——

func _exit_tree() -> void:
	if _handler != null:
		_handler.cancel()


## 某个动作（"down"、"jump"……）现在按着没有（自己这套键）
func action_held(a: String) -> bool:
	return Input.is_action_pressed(_act(a))


func attack_held() -> bool:
	return _stun <= 0.0 and Input.is_action_pressed(_act("attack"))


func attack_pressed() -> bool:
	return _stun <= 0.0 and Input.is_action_just_pressed(_act("attack"))


func find_target() -> Node2D:
	_target = _find_target()
	return _target


func clear_target() -> void:
	_target = null


func aim_dir(from: Vector2) -> Vector2:
	var dir := Vector2(facing, 0)
	if _target != null and is_instance_valid(_target):
		dir = (_aim_point(_target) - from).normalized()
		if signf(dir.x) != 0.0:
			facing = int(signf(dir.x))
	return dir


func target_point(n: Node2D) -> Vector2:
	return _aim_point(n)


func muzzle(dx := 6.0, dy := -10.0) -> Vector2:
	return global_position + Vector2(facing * dx, dy)


func recoil(v: Vector2) -> void:
	velocity += v


func pop(squash := 0.3, light := 0.5) -> void:
	_squash = maxf(_squash, squash)
	_release_flash = maxf(_release_flash, light)


func quick_level() -> int:
	return charge_level


func _aim_point(n: Node2D) -> Vector2:
	if n.has_method("aim_point"):
		return n.call("aim_point")
	return n.global_position


func _find_target() -> Node2D:
	var from := global_position + Vector2(0, -11)
	var space := get_world_2d().direct_space_state
	var best: Node2D = null
	var best_score := INF
	for e in get_tree().get_nodes_in_group("enemy"):
		var en := e as Node2D
		if en == null or (en.has_method("is_targetable") and not en.call("is_targetable")):
			continue
		var p := _aim_point(en)
		var d := from.distance_to(p)
		if d > (AIM_RANGE_BOSS if en.has_method("start_fight") else AIM_RANGE):
			continue
		var score := d
		if (p.x - global_position.x) * facing < 0.0:
			score *= BEHIND_PENALTY
		if score >= best_score:
			continue
		if not _line_clear(space, from, p):
			continue
		best = en
		best_score = score
	return best


## 视线有没有被挡住：单向平台不算挡（子弹也能从下往上穿过它们）
func _line_clear(space: PhysicsDirectSpaceState2D, from: Vector2, to: Vector2) -> bool:
	var q := PhysicsRayQueryParameters2D.create(from, to, 1)
	for _i in 4:
		var hit := space.intersect_ray(q)
		if hit.is_empty():
			return true
		if not is_one_way_body(hit["collider"]):
			return false
		q.exclude = q.exclude + [hit["rid"]]
	return false


## 这个物体是不是一块单向平台（身上所有碰撞形状都是 one_way_collision）
static func is_one_way_body(body: Object) -> bool:
	var b := body as CollisionObject2D
	if b == null or b.get_shape_owners().is_empty():
		return false
	for owner_id in b.get_shape_owners():
		var o := b.shape_owner_get_owner(owner_id)
		if not ((o is CollisionShape2D or o is CollisionPolygon2D) and o.get("one_way_collision")):
			return false
	return true


func _crystal_input() -> void:
	if not Input.is_action_just_pressed(_act("crystal")) or _stun > 0.0:
		return
	if crystal:
		crystal.drop()
		return
	var best: Crystal = null
	var best_d := Crystal.PICK_RANGE
	for c in get_tree().get_nodes_in_group("crystal"):
		var cr := c as Crystal
		if cr == null or cr.carrier != null:
			continue
		var d := (cr.global_position + Vector2(0, -5)).distance_to(global_position + Vector2(0, -8))
		if d < best_d:
			best = cr
			best_d = d
	if best:
		best.pick_up(self)


## 外力，像素/秒。每帧都要重新调用（Boss 吸气时一直往炉门拽）
func push(v: Vector2) -> void:
	_push += v


## 被敌人碰到。返回 true 表示这一下算数（不在无敌时间里）
func hurt(from: Vector2, damage: float) -> bool:
	if _invuln > 0.0 or Game.invincible:
		return false
	_invuln = INVULN_TIME
	var away := signf(global_position.x - from.x)
	if away == 0.0:
		away = -facing
	velocity = Vector2(away * 130.0, -120.0)
	if crystal:
		crystal.take_carried_hit(damage)
		Run.add_emotion(EMOTION_HIT_CARRY)
	else:
		_stun = STUN_TIME
		Run.add_emotion(EMOTION_HIT_EMPTY)
	_cancel_charge()
	Game.sfx("hurt", -4.0)
	Game.flash(Color(1, 0.1, 0.1), 0.16, 0.4)
	Game.add_shake(3.0)
	Game.hitstop(0.08, 0.25)
	return true


func _animate(delta: float) -> void:
	_anim_time += delta
	var frame: int
	if not is_on_floor():
		frame = 4 if velocity.y < 0.0 else 6
	elif absf(velocity.x) > 6.0:
		_walk_time += delta * clampf(absf(velocity.x) / RUN_SPEED, 0.5, 1.2)
		frame = 4 + int(_walk_time / WALK_FRAME_TIME) % 3
		if frame == 4 and _last_walk_frame != 4 and absf(velocity.x) > RUN_SPEED * 0.5:
			Game.dust(get_parent(), global_position + Vector2(-facing * 3, 0), 2, -facing)
	else:
		_walk_time = 0.0
		frame = int(_anim_time / IDLE_FRAME_TIME) % 4
	_last_walk_frame = frame
	# 无敌期间三拍轮着来：藏起来 → 高亮 → 正常，比只隐藏显眼，一看就知道自己现在不会挨打
	var blink_phase := int(_invuln / BLINK_STEP) % 3 if _invuln > 0.0 else -1
	var blink_hidden := blink_phase == 0
	# 不再把图片对齐到整数世界像素（2026-10-18，游戏细节讨论会话，作者反馈"角色略微颤抖"）：
	# 镜头是平滑移动的（位置带小数），图片取整反而一格一格地跳；真实窗口实测主角在屏幕上
	# 每帧 +0.52、+0.52、+0.52、-1.55 这样锯齿抖。不取整以后图片跟着插值后的位置平滑走，像素照样是方的
	_snap = Vector2.ZERO
	# 缩一下：先猛地压扁，再带一点回弹恢复
	var k := _squash
	var sq := Vector2.ONE.lerp(SQUASH_SCALE, k * k) if k > 0.35 else Vector2.ONE.lerp(Vector2(0.92, 1.1), sin(k / 0.35 * PI))
	for s in [_body, _strip]:
		s.position = _snap
		s.scale = sq
		s.frame = frame
		s.flip_h = facing < 0
		s.visible = not blink_hidden

	var glow := charge if (charging and weapon() == "flash") else 0.0
	if _handler != null:
		glow = _handler.glow()
	var pulse := 0.0
	if charge_full:
		pulse = 0.08 + 0.08 * sin(_anim_time * 10.0)
	_body.modulate = Color.WHITE.lerp(Color(1.7, 1.6, 1.5), clampf(glow * 0.35 + pulse + _ring * 0.4, 0.0, 1.0))
	_strip.modulate = Color.WHITE.lerp(Color(2.2, 2.2, 2.2), clampf(glow * 0.6 + _ring * 0.6, 0.0, 1.0))
	if blink_phase == 1:
		_body.modulate = Color(2.6, 2.6, 2.6)
		_strip.modulate = Color(2.6, 2.6, 2.6)
	_light.energy = 0.8 + glow * 1.4 + pulse + _release_flash * 2.5
	_light.texture_scale = 1.0 + glow * 0.8 + _release_flash * 1.6


func _draw() -> void:
	_draw_fuel()
	_draw_weapon()
	if _gather > 0.0:
		# 蓄力开始：一圈光点从外往里收
		var gr := lerpf(3.0, 14.0, _gather)
		var gcol := Color(strip_color.r, strip_color.g, strip_color.b, 0.9 * _gather)
		for i in 12:
			var a := TAU * i / 12.0 + _gather
			_px(Vector2(0, -10) + Vector2(cos(a), sin(a)) * gr, gcol)
	if _ring > 0.0:
		var r := 5.0 + (1.0 - _ring) * 10.0
		var col := Color(1, 1, 1, _ring)
		for i in 20:
			var a := TAU * i / 20.0
			_px(Vector2(0, -10) + Vector2(cos(a), sin(a)) * r, col)


func _draw_weapon() -> void:
	if _handler != null and _handler_id == weapon():
		_handler.draw(self)
		return
	match weapon():
		"flash":
			if _flash_muzzle > 0.0:
				_draw_flash_muzzle()
			if not charging:
				return
			var c := Vector2(0, -10)
			# 几颗光点慢慢往里收（没蓄满时才有）
			if not charge_full:
				var n := 2 + int(charge * 3.0)
				for i in n:
					var ph := fmod(_anim_time * 1.4 + float(i) / n, 1.0)
					var a := float(i) * 2.399 + _anim_time * 0.7
					_px(c + Vector2(cos(a), sin(a)) * lerpf(16.0, 4.0, ph), Color(strip_color, 0.2 + 0.5 * ph))
			# 蓄力圈：一圈 12 个小点，只画亮了的，从正上方顺时针一个个亮；满了整圈变白、轻轻呼吸
			var lit := int(charge * CHARGE_DOTS)
			for i in CHARGE_DOTS:
				if not charge_full and i >= lit:
					continue
				var a := -PI / 2.0 + TAU * i / CHARGE_DOTS
				var p := c + Vector2(cos(a), sin(a)) * CHARGE_RING_R
				var col := strip_color.lerp(Color.WHITE, 0.3)
				if charge_full:
					col = Color(1, 1, 1, 0.85 + 0.15 * sin(_anim_time * 8.0))
				_px(p, col)
		"rivet":
			if _muzzle > 0.0:
				# 枪口火光（大一点，两种形状一发一换）：十字星 / 往前喷的尖火
				var m := Vector2(facing * 8, -10)
				var hot := Color(1.0, 0.95, 0.75)
				var warm := Color(1.0, 0.7, 0.3)
				draw_rect(Rect2(m + Vector2(-1, -1) + _snap, Vector2(2, 2)), Color.WHITE)
				if _rivet_n % 2 == 0:
					for d in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
						_px(m + d * 2, hot)
						_px(m + d * 3, warm)
					_px(m + Vector2(facing * 4, 0), warm)
				else:
					for i in range(2, 6):
						_px(m + Vector2(facing * i, 0), hot if i < 4 else warm)
					_px(m + Vector2(facing * 2, -1), warm)
					_px(m + Vector2(facing * 2, 1), warm)
					_px(m + Vector2(facing * 3, -2), warm)
					_px(m + Vector2(facing * 3, 2), warm)
		"hammer":
			if _hammer_cd > 0.0:
				# 冷却圈：脚下一道弧，冷却完就补满
				var k := 1.0 - _hammer_cd / hammer_cooldown()
				var n := 9
				for i in n:
					if float(i) / n >= k:
						continue
					var a := PI + PI * i / (n - 1)
					var p := Vector2(0, -1) + Vector2(cos(a) * 8.0, sin(a) * 2.0 + 2.0)
					_px(p, Color(strip_color, 0.5))


## 闪光灯出手的火光：蓄满是一大团白光 + 往前喷的长尖 + 斜着四道光刺；没蓄满是小十字星。
## 都是一格一格的像素，3~4 帧就没了
func _draw_flash_muzzle() -> void:
	var m := Vector2(facing * 6, -11)
	var hot := Color(1.0, 0.97, 0.85)
	var glow := strip_color.lerp(Color.WHITE, 0.45)
	if _flash_muzzle_full:
		var core := 2 if _flash_muzzle > 0.5 else 1
		draw_rect(Rect2(m - Vector2(core, core) + _snap, Vector2(core * 2 + 1, core * 2 + 1)), Color.WHITE)
		var reach := 9 if _flash_muzzle > 0.5 else 6
		for i in range(core + 1, reach):
			_px(m + Vector2(facing * i, 0), hot if i < 6 else glow)
		for i in range(core + 1, 5):
			_px(m + Vector2(0, -i), glow)
			_px(m + Vector2(0, i), glow)
			_px(m + Vector2(-facing * (i - 1), 0), glow)
		for d in [Vector2(1, 1), Vector2(1, -1), Vector2(-1, 1), Vector2(-1, -1)]:
			_px(m + d * 3, glow)
			if _flash_muzzle > 0.5:
				_px(m + d * 4, Color(glow, 0.6))
	else:
		draw_rect(Rect2(m - Vector2.ONE + _snap, Vector2(2, 2)), Color.WHITE)
		for d in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
			_px(m + d * 2, glow)
		_px(m + Vector2(facing * 3, 0), hot)


## 背后的小弧形油量表。满油而且没在飞就不画
func _draw_fuel() -> void:
	if fuel >= 1.0 and not _jetting:
		return
	var center := Vector2(-facing * 4, -10)
	const R := 7.0
	const N := 13
	var low := fuel < 0.25 and int(_anim_time * 8.0) % 2 == 0
	for i in N:
		var k := float(i) / (N - 1)  # 0 = 下端，1 = 上端
		var a := deg_to_rad(lerpf(60.0, -60.0, k))
		var p := center + Vector2(-facing * cos(a), sin(a)) * R
		var filled := k < fuel
		var col := strip_color if filled else Color(0.2, 0.2, 0.22, 0.7)
		if filled and low:
			col = Color(1, 0.3, 0.25)
		_px(p, col)


func _draw_reticle() -> void:
	if _target == null or not is_instance_valid(_target):
		return
	var p := _aim_point(_target) + Vector2(0, -12)
	_reticle.global_position = p.round()
	var col := strip_color
	if charge_full and int(_anim_time * 10.0) % 2 == 0:
		col = Color.WHITE
	_reticle.draw_rect(Rect2(-2, 0, 5, 1), col)
	_reticle.draw_rect(Rect2(-1, 1, 3, 1), col)
	_reticle.draw_rect(Rect2(0, 2, 1, 1), col)


func _px(p: Vector2, col: Color) -> void:
	draw_rect(Rect2(p.round() + _snap, Vector2.ONE), col)
